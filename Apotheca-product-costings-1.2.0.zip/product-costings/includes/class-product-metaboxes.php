<?php
/**
 * Registers and renders metaboxes on the Products CPT edit screen.
 * - Formula Ingredients repeater
 * - Cost Summary (reads existing CPT meta fields for calculations)
 *
 * Existing Products CPT meta fields (NOT managed by this plugin):
 *   batch_size, labour, facility_running_costs, misc_costs,
 *   packaging_unit_cost, packaging_units_per_batch, unit_size,
 *   final_ph, cost_price, wholesale, rrp, method
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PC_Product_Metaboxes {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'add_meta_boxes', array( $this, 'register_metaboxes' ) );
        add_action( 'save_post_products', array( $this, 'save_meta' ), 10, 2 );
    }

    public function register_metaboxes() {
        add_meta_box(
            'pc_formula_ingredients',
            __( 'Formula Ingredients', 'product-costings' ),
            array( $this, 'render_formula_metabox' ),
            'products',
            'normal',
            'high'
        );

        add_meta_box(
            'pc_cost_summary',
            __( 'Cost Summary', 'product-costings' ),
            array( $this, 'render_cost_summary_metabox' ),
            'products',
            'normal',
            'default'
        );
    }

    /* ───────────────────────────────────────────────
     * Formula Ingredients Repeater
     * ─────────────────────────────────────────────── */

    public function render_formula_metabox( $post ) {
        wp_nonce_field( 'pc_save_formula', 'pc_formula_nonce' );

        $rows = get_post_meta( $post->ID, '_pc_formula_rows', true );
        if ( ! is_array( $rows ) ) {
            $rows = array();
        }

        $functions = PC_Formula_Functions::get_functions();
        ?>
        <div id="pc-formula-wrap">
            <table id="pc-formula-table" class="widefat pc-formula-table">
                <thead>
                    <tr>
                        <th class="pc-col-sort">&nbsp;</th>
                        <th class="pc-col-to100"><?php esc_html_e( 'To 100%', 'product-costings' ); ?></th>
                        <th class="pc-col-phase"><?php esc_html_e( 'Phase', 'product-costings' ); ?></th>
                        <th class="pc-col-ww"><?php esc_html_e( '% w/w', 'product-costings' ); ?></th>
                        <th class="pc-col-trade"><?php esc_html_e( 'Trade Name', 'product-costings' ); ?></th>
                        <th class="pc-col-function"><?php esc_html_e( 'Function', 'product-costings' ); ?></th>
                        <th class="pc-col-ph"><?php esc_html_e( 'pH Range', 'product-costings' ); ?></th>
                        <th class="pc-col-price"><?php esc_html_e( 'Price/KG', 'product-costings' ); ?></th>
                        <th class="pc-col-moq"><?php esc_html_e( 'MOQ', 'product-costings' ); ?></th>
                        <th class="pc-col-nat-origin"><?php esc_html_e( 'Nat. Origin %', 'product-costings' ); ?></th>
                        <th class="pc-col-actions">&nbsp;</th>
                    </tr>
                </thead>
                <tbody id="pc-formula-body">
                    <?php
                    if ( ! empty( $rows ) ) {
                        foreach ( $rows as $i => $row ) {
                            $this->render_row( $i, $row, $functions );
                        }
                    }
                    ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3" class="pc-total-label"><strong><?php esc_html_e( 'Total % w/w:', 'product-costings' ); ?></strong></td>
                        <td id="pc-total-ww"><strong>0.00</strong></td>
                        <td colspan="7"></td>
                    </tr>
                </tfoot>
            </table>

            <p style="margin-top:12px;">
                <button type="button" id="pc-add-row" class="button button-primary">
                    <?php esc_html_e( '+ Add Ingredient', 'product-costings' ); ?>
                </button>
                <button type="button" id="pc-refresh-meta" class="button">
                    <?php esc_html_e( '↻ Refresh Ingredient Data', 'product-costings' ); ?>
                </button>
                <span id="pc-refresh-status"></span>
            </p>

            <div id="pc-formula-warnings"></div>

            <p style="margin-top:12px;">
                <label for="pc-version-note"><strong><?php esc_html_e( 'Version note', 'product-costings' ); ?></strong></label>
                <input type="text" id="pc-version-note" name="pc_version_note" class="regular-text" placeholder="<?php esc_attr_e( 'e.g. Increased glycerin to 3%, swapped preservative', 'product-costings' ); ?>" style="width:60%;">
                <span class="description"><?php esc_html_e( 'Saved with the automatic formula version when this formula changes.', 'product-costings' ); ?></span>
            </p>
        </div>

        <!-- Row template (hidden) -->
        <script type="text/html" id="tmpl-pc-row">
            <tr class="pc-row" data-index="{{data.i}}">
                <td class="pc-col-sort pc-drag-handle">&#9776;</td>
                <td class="pc-col-to100">
                    <input type="checkbox" name="pc_rows[{{data.i}}][is_to_100]" value="1" class="pc-field-to100">
                </td>
                <td class="pc-col-phase">
                    <input type="text" name="pc_rows[{{data.i}}][phase]" value="" placeholder="A" class="pc-field-phase" maxlength="5">
                </td>
                <td class="pc-col-ww">
                    <input type="number" name="pc_rows[{{data.i}}][percent_w_w]" value="" step="any" min="0" max="100" class="pc-field-ww" placeholder="0.00">
                </td>
                <td class="pc-col-trade">
                    <select name="pc_rows[{{data.i}}][trade_name_id]" class="pc-field-trade-name">
                        <option value=""><?php esc_html_e( '— Select —', 'product-costings' ); ?></option>
                    </select>
                </td>
                <td class="pc-col-function">
                    <select name="pc_rows[{{data.i}}][function]" class="pc-field-function">
                        <option value=""><?php esc_html_e( '— Select —', 'product-costings' ); ?></option>
                        <?php foreach ( $functions as $fn ) : ?>
                            <option value="<?php echo esc_attr( $fn ); ?>"><?php echo esc_html( $fn ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
                <td class="pc-col-ph">
                    <input type="text" name="pc_rows[{{data.i}}][ph]" value="" class="pc-field-ph" readonly>
                </td>
                <td class="pc-col-price">
                    <input type="text" name="pc_rows[{{data.i}}][price_per_kg]" value="" class="pc-field-price" readonly>
                </td>
                <td class="pc-col-moq">
                    <input type="text" name="pc_rows[{{data.i}}][moq]" value="" class="pc-field-moq" readonly>
                </td>
                <td class="pc-col-nat-origin">
                    <input type="text" name="pc_rows[{{data.i}}][natural_origin]" value="" class="pc-field-natural-origin" readonly>
                </td>
                <td class="pc-col-actions">
                    <button type="button" class="button pc-inci-toggle" title="<?php esc_attr_e( 'INCI breakdown for packaging', 'product-costings' ); ?>"><?php esc_html_e( 'INCI', 'product-costings' ); ?></button>
                    <button type="button" class="button pc-duplicate-row" title="<?php esc_attr_e( 'Duplicate', 'product-costings' ); ?>">&#x2398;</button>
                    <button type="button" class="button pc-remove-row" title="<?php esc_attr_e( 'Remove', 'product-costings' ); ?>">&#x1F5D1;</button>
                </td>
            </tr>
        </script>
        <?php
    }

    /**
     * Render a single repeater row.
     */
    private function render_row( $i, $row, $functions ) {
        $phase     = isset( $row['phase'] ) ? $row['phase'] : '';
        $ww        = isset( $row['percent_w_w'] ) ? $row['percent_w_w'] : '';
        $trade_id  = isset( $row['trade_name_id'] ) ? (int) $row['trade_name_id'] : 0;
        $fn_val    = isset( $row['function'] ) ? $row['function'] : '';
        $ph        = isset( $row['ph'] ) ? $row['ph'] : ( isset( $row['ph_range'] ) ? $row['ph_range'] : '' );
        $price     = isset( $row['price_per_kg'] ) ? $row['price_per_kg'] : '';
        $moq       = isset( $row['moq'] ) ? $row['moq'] : '';
        $nat_orig  = isset( $row['natural_origin'] ) ? $row['natural_origin'] : '';
        $is_to_100 = isset( $row['is_to_100'] ) ? (bool) $row['is_to_100'] : false;

        // Live data for guardrails + stale-price detection.
        $usage_min = '';
        $usage_max = '';
        $stale     = false;
        $cur_price = '';
        if ( $trade_id ) {
            $usage_min = PC_Trade_Data::get( $trade_id, 'usage_min' );
            $usage_max = PC_Trade_Data::get( $trade_id, 'usage_max' );
            $cur_price = PC_Trade_Data::get( $trade_id, 'price_per_kg' );
            if ( '' !== $price && '' !== $cur_price && abs( floatval( $price ) - floatval( $cur_price ) ) > 0.0001 ) {
                $stale = true;
            }
        }
        ?>
        <tr class="pc-row <?php echo $is_to_100 ? 'pc-row-to100' : ''; ?>" data-index="<?php echo (int) $i; ?>" data-usage-min="<?php echo esc_attr( $usage_min ); ?>" data-usage-max="<?php echo esc_attr( $usage_max ); ?>">
            <td class="pc-col-sort pc-drag-handle">&#9776;</td>
            <td class="pc-col-to100">
                <input type="checkbox" name="pc_rows[<?php echo (int) $i; ?>][is_to_100]" value="1" class="pc-field-to100" <?php checked( $is_to_100 ); ?>>
            </td>
            <td class="pc-col-phase">
                <input type="text" name="pc_rows[<?php echo (int) $i; ?>][phase]" value="<?php echo esc_attr( $phase ); ?>" placeholder="A" class="pc-field-phase" maxlength="5">
            </td>
            <td class="pc-col-ww">
                <input type="number" name="pc_rows[<?php echo (int) $i; ?>][percent_w_w]" value="<?php echo esc_attr( $ww ); ?>" step="any" min="0" max="100" class="pc-field-ww" placeholder="0.00" <?php echo $is_to_100 ? 'readonly' : ''; ?>>
                <?php if ( $is_to_100 ) : ?>
                    <span class="pc-to100-badge"><?php esc_html_e( 'to 100%', 'product-costings' ); ?></span>
                <?php endif; ?>
            </td>
            <td class="pc-col-trade">
                <select name="pc_rows[<?php echo (int) $i; ?>][trade_name_id]" class="pc-field-trade-name">
                    <option value=""><?php esc_html_e( '— Select —', 'product-costings' ); ?></option>
                    <?php if ( $trade_id ) : ?>
                        <option value="<?php echo $trade_id; ?>" selected><?php echo esc_html( get_the_title( $trade_id ) ); ?></option>
                    <?php endif; ?>
                </select>
            </td>
            <td class="pc-col-function">
                <select name="pc_rows[<?php echo (int) $i; ?>][function]" class="pc-field-function">
                    <option value=""><?php esc_html_e( '— Select —', 'product-costings' ); ?></option>
                    <?php foreach ( $functions as $fn ) : ?>
                        <option value="<?php echo esc_attr( $fn ); ?>" <?php selected( $fn_val, $fn ); ?>><?php echo esc_html( $fn ); ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
            <td class="pc-col-ph">
                <input type="text" name="pc_rows[<?php echo (int) $i; ?>][ph]" value="<?php echo esc_attr( $ph ); ?>" class="pc-field-ph" readonly>
            </td>
            <td class="pc-col-price">
                <input type="text" name="pc_rows[<?php echo (int) $i; ?>][price_per_kg]" value="<?php echo esc_attr( $price ); ?>" class="pc-field-price" readonly>
                <?php if ( $stale ) : ?>
                    <span class="pc-stale-badge" title="<?php echo esc_attr( sprintf( __( 'Current Trade Name price is %s — use Refresh Ingredient Data to update.', 'product-costings' ), $cur_price ) ); ?>">!</span>
                <?php endif; ?>
            </td>
            <td class="pc-col-moq">
                <input type="text" name="pc_rows[<?php echo (int) $i; ?>][moq]" value="<?php echo esc_attr( $moq ); ?>" class="pc-field-moq" readonly>
            </td>
            <td class="pc-col-nat-origin">
                <input type="text" name="pc_rows[<?php echo (int) $i; ?>][natural_origin]" value="<?php echo esc_attr( $nat_orig ); ?>" class="pc-field-natural-origin" readonly>
            </td>
            <td class="pc-col-actions">
                <button type="button" class="button pc-inci-toggle" title="<?php esc_attr_e( 'INCI breakdown for packaging', 'product-costings' ); ?>"><?php esc_html_e( 'INCI', 'product-costings' ); ?></button>
                <button type="button" class="button pc-duplicate-row" title="<?php esc_attr_e( 'Duplicate', 'product-costings' ); ?>">&#x2398;</button>
                <button type="button" class="button pc-remove-row" title="<?php esc_attr_e( 'Remove', 'product-costings' ); ?>">&#x1F5D1;</button>
            </td>
        </tr>
        <?php
    }

    /* ───────────────────────────────────────────────
     * Cost Summary (reads existing CPT meta fields)
     * ─────────────────────────────────────────────── */

    public function render_cost_summary_metabox( $post ) {
        $waste = get_post_meta( $post->ID, '_pc_waste_percent', true );
        if ( '' === $waste ) {
            $waste = 2;
        }
        ?>
        <div id="pc-cost-summary" class="pc-cost-summary">
            <p class="description"><?php esc_html_e( 'Values are calculated automatically from the formula ingredients and the product meta fields above. Ingredient purchasing is rounded up to each ingredient\'s MOQ, matching the front-end Batch Costings widget.', 'product-costings' ); ?></p>
            <p>
                <label for="pc-waste-percent"><strong><?php esc_html_e( 'Waste %', 'product-costings' ); ?></strong></label>
                <input type="number" id="pc-waste-percent" name="pc_waste_percent" value="<?php echo esc_attr( $waste ); ?>" step="0.5" min="0" max="50" style="width:70px;">
                <span class="description"><?php esc_html_e( 'Manufacturing waste allowance added to batch size. Set this to the same value as the Batch Costings widget to match front-end figures.', 'product-costings' ); ?></span>
            </p>
            <table class="widefat striped">
                <tr>
                    <th><?php esc_html_e( 'Raw Material Cost per KG', 'product-costings' ); ?></th>
                    <td id="pc-raw-cost-kg">&mdash;</td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Ingredient Cost per Batch (MOQ purchase)', 'product-costings' ); ?></th>
                    <td id="pc-raw-cost-batch">&mdash;</td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Units per Batch', 'product-costings' ); ?></th>
                    <td id="pc-units-batch">&mdash;</td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Total Batch Cost', 'product-costings' ); ?></th>
                    <td id="pc-batch-cost">&mdash;</td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Cost per Unit', 'product-costings' ); ?></th>
                    <td id="pc-cost-unit">&mdash;</td>
                </tr>
            </table>

            <h4><?php esc_html_e( 'Cost Drivers', 'product-costings' ); ?></h4>
            <p class="description"><?php esc_html_e( 'Each ingredient\'s share of formula weight vs its share of raw material cost (before MOQ purchasing effects). Big gaps between the two bars show where reformulation saves the most money.', 'product-costings' ); ?></p>
            <div id="pc-cost-drivers"><em><?php esc_html_e( 'Add ingredients with prices to see the breakdown.', 'product-costings' ); ?></em></div>

            <h4><?php esc_html_e( 'Batch Size Sweet Spot', 'product-costings' ); ?></h4>
            <p class="description"><?php esc_html_e( 'Cost per unit at different batch sizes. Because ingredient purchasing rounds up to MOQ multiples, unit cost is not linear — this shows where the cliffs are. Assumes labour, facility and misc costs are fixed per batch.', 'product-costings' ); ?></p>
            <div id="pc-sweet-spot"><em><?php esc_html_e( 'Requires Batch Size and Unit Size to be set.', 'product-costings' ); ?></em></div>
        </div>
        <?php
    }

    /* ───────────────────────────────────────────────
     * Save
     * ─────────────────────────────────────────────── */

    public function save_meta( $post_id, $post ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( wp_is_post_revision( $post_id ) ) {
            return;
        }
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        // --- Formula rows ---
        if ( isset( $_POST['pc_formula_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['pc_formula_nonce'] ) ), 'pc_save_formula' ) ) {
            $raw_rows = isset( $_POST['pc_rows'] ) && is_array( $_POST['pc_rows'] ) ? wp_unslash( $_POST['pc_rows'] ) : array();
            $clean    = array();

            if ( is_array( $raw_rows ) ) {
                foreach ( $raw_rows as $row ) {
                    $clean[] = array(
                        'phase'          => sanitize_text_field( $row['phase'] ?? '' ),
                        'percent_w_w'    => floatval( $row['percent_w_w'] ?? 0 ),
                        'trade_name_id'  => absint( $row['trade_name_id'] ?? 0 ),
                        'function'       => sanitize_text_field( $row['function'] ?? '' ),
                        'ph'             => sanitize_text_field( $row['ph'] ?? '' ),
                        'price_per_kg'   => sanitize_text_field( $row['price_per_kg'] ?? '' ),
                        'moq'            => sanitize_text_field( $row['moq'] ?? '' ),
                        'natural_origin' => sanitize_text_field( $row['natural_origin'] ?? '' ),
                        'is_to_100'      => ! empty( $row['is_to_100'] ) ? true : false,
                    );
                }
            }

            update_post_meta( $post_id, '_pc_formula_rows', $clean );

            // --- Waste % (used by the admin Cost Summary calculation) ---
            if ( isset( $_POST['pc_waste_percent'] ) ) {
                $waste = floatval( wp_unslash( $_POST['pc_waste_percent'] ) );
                $waste = max( 0, min( 50, $waste ) );
                update_post_meta( $post_id, '_pc_waste_percent', $waste );
            }
        }
    }
}
